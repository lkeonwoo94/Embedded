#include "2450addr.h"
#include "option.h"
#include "libc.h"

//Function Declaration 
void Key_Port_Init(void);
void Key_Get_Pressed_with_LED();
int Key_Get_Pressed();
int Key_Wait_Get_Pressed();
void Key_Wait_Get_Released();

//Function
void Key_Port_Init(void)
{
	/* GPFCON -Input Mode GPF[2:6] */
	/* YOUR CODE HERE */

}

/*void Key_Get_Pressed_with_LED()
{
	// TO DO : [1]1�� key => LED1, [2]2�� key => LED2, [3]3�� key => LED3, [4]4�� key => LED4
	int i;	

	rGPFDAT &= ~(0x1<<7);

	if((~(rGPFDAT) >> 2) & 0x1)
	{
		rGPGDAT &= ~(0x1<<4);
		for(i=0;i<0xffff;i++);
		rGPGDAT |= (0x1<<4);
				
	}

	if((~(rGPFDAT) >>3) & 0x1)
	{
		rGPGDAT &= ~(0x1<<5);
		for(i=0;i<0xffff;i++);
		rGPGDAT |= (0x1<<5);
	}
	if((~(rGPFDAT) >>4) & 0x1)	
	{
		rGPGDAT &= ~(0x1<<6);
		for(i=0;i<0xffff;i++);
		rGPGDAT |= (0x1<<6);
	}
	if((~(rGPFDAT) >>5) & 0x01)
	{
		rGPGDAT &= ~(0x1<<7);
		for(i=0;i<0xffff;i++);
		rGPGDAT |= (0X1<<7);
	}	
}*/

int Key_Get_Pressed()
{

}

int Key_Wait_Get_Pressed()
{
}

void Key_Wait_Get_Released()
{	
	/* TO DO : Ű�� �������� �ʾ��� ���� ��Ÿ���� �Լ� */
}
