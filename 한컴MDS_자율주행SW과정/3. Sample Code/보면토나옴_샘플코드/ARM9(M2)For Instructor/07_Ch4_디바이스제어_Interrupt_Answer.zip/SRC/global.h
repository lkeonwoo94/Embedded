#ifndef __GLOBAL_H__
#define __GLOBAL_H__

unsigned long src=0x33000000;
unsigned long dst=0x33100000;
unsigned int  size = 12; /* word size */
unsigned long pattern;